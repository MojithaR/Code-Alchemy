#include<iostream>
using namespace std;

int main()
{
    cout<<"Hellp world"<<endl;
    return 0;

}